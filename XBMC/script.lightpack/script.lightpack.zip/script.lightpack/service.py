
#Modules General
import os,lightpack
import time
from sys import argv

# Modules XBMC
import xbmc, xbmcgui, xbmcaddon

__settings__ = xbmcaddon.Addon( "script.lightpack" )
__language__ = __settings__.getLocalizedString

#########################################################################################################
## BEGIN
#########################################################################################################
print "service Lightpack"
# set on
import os.path
icon=__settings__.getAddonInfo( "icon" )
smallicon = icon.encode( "utf-8" )
xbmc.executebuiltin('Notification(Lightpack,Connection API...,3000,' + smallicon + ')')
print "service Lightpack connect"
lpack = lightpack.lightpack(__settings__.getSetting("host"), int(__settings__.getSetting("port")), __settings__.getSetting("apikey"), [1,2,3,4,5,6,7,8,9,10] )
lpack.connect()
print "service Lightpack set on"
lpack.lock()
lpack.turnOn()
lpack.unlock
oldstatus = -1
while (not xbmc.abortRequested):
	#print "service lightpack status " + str(oldstatus)
	newstatus = 0
	player = xbmc.Player()
	audioIsPlaying = player.isPlayingAudio()
	videoIsPlaying = player.isPlayingVideo()
	if videoIsPlaying:
		newstatus = 1
	if audioIsPlaying:
		newstatus = 2
	if (oldstatus!=newstatus):
		oldstatus = newstatus
		lpack.lock()
		if (newstatus == 0):
			lpack.setProfile(__settings__.getSetting("default_profile"))
			xbmc.executebuiltin('Notification(Lightpack,Set profile '+__settings__.getSetting("default_profile")+',3000,' + smallicon + ')')
		if (newstatus == 1):
			lpack.setProfile(__settings__.getSetting("video_profile"))
			xbmc.executebuiltin('Notification(Lightpack,Set profile '+__settings__.getSetting("video_profile")+',3000,' + smallicon + ')')
		if (newstatus == 2):
			lpack.setProfile(__settings__.getSetting("audio_profile"))
			xbmc.executebuiltin('Notification(Lightpack,Set profile '+__settings__.getSetting("audio_profile")+',3000,' + smallicon + ')')
		lpack.unlock()
	time.sleep(1)
	
# set off
xbmc.executebuiltin('Notification(Lightpack,Set status OFF,3000,' + smallicon + ')')
print "set status off for Lightpack"
#lpack = lightpack.lightpack(__settings__.getSetting("host"), int(__settings__.getSetting("port")), __settings__.getSetting("apikey"), [1,2,3,4,5,6,7,8,9,10] )
#lpack.connect()
lpack.lock()
lpack.turnOff()
lpack.unlock
lpack.disconnect()
