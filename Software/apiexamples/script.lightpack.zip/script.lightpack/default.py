
#Modules General
import os,lightpack
from sys import argv

# Modules XBMC
import xbmc, xbmcgui, xbmcaddon

__settings__ = xbmcaddon.Addon( "script.lightpack" )
#########################################################################################################
## BEGIN
#########################################################################################################
lpack = lightpack.lightpack(__settings__.getSetting("host"), int(__settings__.getSetting("port")), [1,2,3,4,5,6,7,8,9,10] )
lpack.connect()
profiles = lpack.getProfiles()
menu = profiles
off = len(profiles) - 1
menu[off]="Off"
quit = False

while not quit:
	selected = xbmcgui.Dialog().select("Select profile", menu )
	print "selected=%s" % selected
	if (off==int(selected)):
		lpack.off()
	else:
		lpack.setProfile(menu[selected])
	quit = True

lpack.disconnect()